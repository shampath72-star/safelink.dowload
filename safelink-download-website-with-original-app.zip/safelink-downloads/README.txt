SAFELINK DOWNLOAD PACKAGE

Included:
- downloads/SafeLink.html : your original uploaded SafeLink app HTML
- app-icon.png : icon extracted from the original app
- SafeLink-Windows.bat : opens the HTML app in your default browser on Windows

WINDOWS
Extract the ZIP, then double-click SafeLink-Windows.bat. Some browser features (camera/microphone, location, SMS, realtime connection) may require HTTPS and/or a backend and may not work when opened as a local file.

ANDROID
The HTML file can be downloaded, but it is NOT an APK. For app-like use, open https://shampath72-star.github.io/safelink/ in Chrome and use the browser menu > Add to Home screen / Install app if offered. A real APK requires packaging and testing separately.

SAFETY NOTE
SafeLink is a backup aid, not a replacement for emergency services.
