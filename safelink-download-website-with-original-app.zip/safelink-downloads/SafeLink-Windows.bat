@echo off
cd /d "%~dp0"
start "" "%~dp0downloads\SafeLink.html"
